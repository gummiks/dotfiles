#!/usr/bin/python
# -*- coding: utf-8 -*-
# File: %FFILE%
# Created: %DATE% by %USER% 
"""
Description: %HERE%
"""
import numpy as np
from pylab import *
from scipy import *
import matplotlib.pyplot as plt
import scipy.constants as const
from scipy import optimize
#import matplotlib.pyplot as plt
#from mpl_toolkits.mplot3d import Axes3D
#from matplotlib import cm

#---------------------FONT and other graphics------------------------
font = {'family'         : 'serif',
	'weight'         : 'bold',
	'size'	         : 16}
matplotlib.rc('font',**font)
matplotlib.rc('grid',linewidth=1)
matplotlib.rc('xtick.major',width=2)
matplotlib.rc('xtick.major',size=7)
matplotlib.rc('xtick.minor',width=2)
matplotlib.rc('xtick.minor',size=4)
matplotlib.rc('ytick.major',width=2)
matplotlib.rc('ytick.major',size=7)
matplotlib.rc('ytick.minor',width=2)
matplotlib.rc('ytick.minor',size=4)

#-------------------------------------------------

#plotall

#---------------------DATA------------------------
name='<++>'
data<++>
<++>= data[:,0]
<++>= data[:,1]

#-------------------------------------------------

#------------Figure Layout--------------
#twofig
#fig11
#fig21
#fig12
#fig13
#---------------------------------------


#FITTING------------------------------------------
#polyfit
#optimize

#-------------------------GRAPHICS
#legend((u'<++>',u'<++>'),loc='upper right')
#legend
#changeticks
#tickRotate
#intTick

#MISC
#plt.ticklabel_format(style="sci",scilimits=(1,2),axis="y")

#ANNOTATE
#ax.annotate(r'$M_r$', xy=(0, 2),  xycoords='data',
#                xytext=(-50, 30), textcoords='data',
#                arrowprops=dict(arrowstyle="->"))
#bx.annotate(r'$\chi^2=0.46$', xy=(750, 0.03),xytext=None, textcoords='data',arrowprops=None)




#SAVING
fig.show()
fig.savefig(name+".pdf")

