#! /usr/bin/env runhugs +l
--
-- %FFILE%
-- Copyright (C) %YEAR% %USER% <%MAIL%>
--
-- Distributed under terms of the MIT license.
--

module %FILE% where


%HERE%
