/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the MIT license.
 */

#include "%FILE%.h"


%HERE%
