---
title: %HERE%
layout: post
image1: /img/<+imagename+>
image1title: <+title+>
image1subtitle: <+title+>
image2: /img/<+imagename+>
image2title: <+title+>
image2subtitle: <+subtitle+>
image3: /img/<+imagename+>
image3title: <+title+>
image3subtitle: <+subtitle+>
image4: /img/<+imagename+>
image4title: <+title+>
image4subtitle: <+subtitle+>
image5: /img/<+imagename+>
image5title: <+title+>
image5subtitle: <+subtitle+>
tags:
- 
---

<++>


<div id="myCarousel" class="carousel slide">
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image1 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image1title }}</p>
					<p class="muted"> {{ page.image1subtitle }}</p>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="myCarousel" class="carousel slide">
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image2 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image2title }}</p>
					<p class="muted"> {{ page.image2subtitle }}</p>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="myCarousel" class="carousel slide">
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image3 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image3title }}</p>
					<p class="muted"> {{ page.image3subtitle }}</p>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="myCarousel" class="carousel slide">
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image4 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image4title }}</p>
					<p class="muted"> {{ page.image4subtitle }}</p>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="myCarousel" class="carousel slide">
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image5 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image5title }}</p>
					<p class="muted"> {{ page.image5subtitle }}</p>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="myCarousel" class="carousel slide">
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
  <!-- Carousel items -->
	<div class="carousel-inner">
		<div class="active item">
			<img class="carouselImage" src=" {{ page.image1 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image1title }}</p>
					<p class="muted"> {{ page.image1subtitle }}</p>
				</div>
			</div></div>
		<div class="item">
			<img class="carouselImage" src=" {{ page.image2 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image2title }}</p>
					<p class="muted"> {{ page.image2subtitle }}</p>
				</div>
			</div></div>
		<div class="item">
			<img class="carouselImage" src=" {{ page.image3 }}"> 
			<div class="container">
				<div class="carousel-caption">
					<p class="lead"> {{ page.image3title }}</p>
					<p class="muted"> {{ page.image3subtitle }}</p>
				</div>
			</div></div>
	</div>
 <!-- Carousel nav -->
  <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
  <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
</div>

<++>
