/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the MIT license.
 */

select %HERE%


-- vim:et
